public class Mago extends Classes{
    public Mago(String nome,int vida,int dano, int defesa, int chaceCritico,
                int chanceEsquivar, int especial, int id) {
        super(nome,vida,dano, defesa, chaceCritico, chanceEsquivar, especial, id);
    }

    @Override
    public String toString() {
        return  "\n"+"Mago " + super.toString();
    }
}
