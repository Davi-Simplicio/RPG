import java.util.Random;


public class Arqueiro extends Classes{
    Random sc = new Random();

    public Arqueiro(String nome,int vida,int dano, int defesa, int chaceCritico,
                    int chanceEsquivar, int especial, int id) {
        super(nome,vida,dano, defesa, chaceCritico, chanceEsquivar, especial, id);

    }

    @Override
    public String toString() {
        return "\n"+"Arqueiro " + super.toString();
    }
}
