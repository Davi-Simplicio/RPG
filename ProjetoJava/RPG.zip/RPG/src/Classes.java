
import java.util.Random;

public abstract class Classes {
    Random sc = new Random();
    private String nome;
    private int vida;
    private int dano;
    private int defesa;
    private int chaceCritico;
    private int chanceEsquivar;
    private int id;
    private int especial;

    public Classes(String nome,int vida, int dano, int defesa, int chaceCritico,
                   int chanceEsquivar, int especial,int id) {
        this.nome = nome;
        this.vida = vida;
        this.dano = dano;
        this.defesa = defesa;
        this.chaceCritico = chaceCritico;
        this.chanceEsquivar = chanceEsquivar;
        this.especial = especial;
        this.id = id;

    }

    public int getVida() {
        return vida;
    }

    public int getDano() {
        return dano;
    }

    public int getDefesa() {
        return defesa;
    }

    public int getChaceCritico() {
        return chaceCritico;
    }

    public int getChanceEsquivar() {
        return chanceEsquivar;
    }

    public int getEspecial() {
        return especial;
    }

    public int getId(){return id;}

    public void setId(int id){
        this.id = id;
    }

    public void atacar(Classes unidadeAdversariaEscolhida) {
        boolean critico;
        System.out.println("Entrou");
        int numeroAleatorio = sc.nextInt(100);
        if(numeroAleatorio > this.getChanceEsquivar()){
            if(numeroAleatorio > this.getChaceCritico()){
                unidadeAdversariaEscolhida.setVida(unidadeAdversariaEscolhida.getVida() - this.getDano());
                System.out.println(this.nome+" infringiu "+this.getDano()+" de dano em "+unidadeAdversariaEscolhida.nome+" que agora está com "+unidadeAdversariaEscolhida.getVida()+" de vida");
            }else{
                unidadeAdversariaEscolhida.setVida(unidadeAdversariaEscolhida.getVida() - this.getDano()*2) ;
                System.out.println(this.nome+" infringiu "+this.getDano()*2+" de dano em "+unidadeAdversariaEscolhida.nome+" que agora está com "+unidadeAdversariaEscolhida.getVida()+" de vida");

            }
        }else{
            System.out.println(unidadeAdversariaEscolhida + " desviou do ataque");
        }

    }

    public void defender() {
        this.setDefesa(this.getDefesa()+25);;
    }


    public void setVida(int vida) {
        this.vida = vida;
    }

    public void setDefesa(int defesa) {
        this.defesa = defesa;
    }

    @Override
    public String toString() {
        return  "["+id+"]"+
                "vida=" + vida +
                ", dano=" + dano +
                ", defesa=" + defesa +
                ", chaceCritico=" + chaceCritico +
                ", chanceEsquivar=" + chanceEsquivar +
                ", especial=" + especial +
                '}';
    }

}
