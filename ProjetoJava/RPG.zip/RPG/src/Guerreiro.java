public class Guerreiro extends Classes {
    public Guerreiro(String nome,int vida,int dano, int defesa, int chaceCritico,
                     int chanceEsquivar, int especial, int id) {
        super(nome,vida,dano, defesa, chaceCritico, chanceEsquivar, especial, id);
    }




    @Override
    public String toString() {
        return  "\n"+"Guerreiro " + super.toString();
    }
}
