import java.util.ArrayList;

public class Jogador {
    String nome;
    int id;
    public ArrayList<Classes> unidades = new ArrayList<>();

    public Jogador(int id, String nome) {
        this.nome = nome;
        this.id = id;

    }


    public ArrayList<Classes> getUnidades() {
        return unidades;
    }

    @Override
    public String toString() {
        return "Jogador{" +
                "nome='" + nome + '\'' +
                ", id=" + id +
                '}';
    }
}
